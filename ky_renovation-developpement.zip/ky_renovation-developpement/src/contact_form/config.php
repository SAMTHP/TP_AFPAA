<?php
define('_to_name', 'KY RENOVATION');
define('_to_email', 'noblartspirit@gmail.com');

define('_smtp_host', 'smtp.gmail.com');
define('_smtp_username', 'noblartspirit@gmail.com');
define('_smtp_password', 'spirit623598741');
define('_smtp_port', '587');
define('_smtp_secure', 'tls'); //ssl or tls

define('_subject_email', 'KY RENOAVATION: SITE WEB');

define('_def_name', 'Votre Nom *');
define('_def_email', 'Votre Email *');
define('_def_phone', 'Votre Téléphone');
define('_def_message', 'Message *');

define('_msg_invalid_data_name', "S'il vous plaît entrez votre nom.");
define('_msg_invalid_data_email', 'Veuillez entrer un e-mail valide.');
define('_msg_invalid_data_message', "S'il vous plaît entrez votre message.");


define('_msg_send_ok', 'KY RENOVATION vous remercie, nous vous contacterons rapidement.');
define('_msg_send_error', 'Désolé, nous ne pouvons pas envoyer ce message.');
?>
